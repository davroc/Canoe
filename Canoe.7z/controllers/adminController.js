const AdminModel= require('../models/AdminUsers');

const db=require('../util/db');

exports.getUsersList =  (req, res, next) => {
  console.log(AdminModel.getUsersList(req,res,next));
  const UserList = AdminModel.getUsersList(req,res,next);
  console.log(UserList);
  //const UserList =['test'];

  res.render('admin/userslist', { pageTitle: 'Utilisateurs', path: '/admin/userslist',Usr: UserList });
};

exports.addUser = (req, res, next) => {
  res.render('admin/adduser', { pageTitle: 'Ajouter un utilisateur', path: '/admin/adduser' });
}

exports.viewUser =(req,res,next) =>{
  db.execute('SELECT * from users where id=10')
  .then(res=>{
    const rs= res[0];
    console.log(rs);
  })
 .catch(err=>{return err});
}

exports.postNewUser = (req, res, next) => {
  //products.push({ title: req.body.title });
  res.redirect('/');
}