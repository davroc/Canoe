const db=require('../util/db');

exports.getUsersList = (req,res,next) =>{  
  //console.log(req);
  db.execute('SELECT * from users')
   .then(res=>{
     return JSON.stringify(res[0]);
   })
  .catch(err=>{return err});
}